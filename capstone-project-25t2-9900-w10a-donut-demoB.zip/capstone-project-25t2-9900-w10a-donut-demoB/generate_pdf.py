import pandas as pd
import matplotlib.pyplot as plt
import random
import io


from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.units import cm

# Resources:
# https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.savefig.html

def generatePDF(path, csv_path):
    # Read CSV File
    df = pd.read_csv(csv_path)

    #Find the columns with numerical value
    number_of_columns = df.select_dtypes(include= "number").columns.to_list()

    # Random pick N columns to do the comparison
    selected_column = random.sample(number_of_columns, min(3, len(number_of_columns)))

    # Compute KPIs
    KPIs = {}
    for col in selected_column:
        total = df[col].sum()
        mean = df[col].mean()
        KPIs[f"Sum of {col}"] = f"{total:.2f}"
        KPIs[f"Average of {col}"] = f"{mean:.2f}"

    c = canvas.Canvas(path, pagesize= A4) # Creates a new PDF canvas and set page size to A4
    width, height = A4 # Unpack the A4 dimensions in points into width and height variable
    c.setFont("Times New Roman", 20) # Font settingf or the subsequent context
    c.drawCentredString(width/2, height - 2*cm, "PDF Report") # Print the "PDF Report" centered horizontally at (x,y)
    
    # Use plt to draw the bar plot
    cols = selected_column
    means = [df[col].mean() for col in cols]
    fig, ax = plt.subplots(figsize = (6,3))
    ax.bar(cols, means)
    ax.set_title("KPI Comparison")
    ax.set_ylabel("Average")
    ax.set_xlabel("Column")
    buf = io.BytesIO()
    plt.savefig(buf, format = "png", bbox_inches = "tight")
    plt.close(fig)

    # Put picture into PDF
    image_height, image_width = height - 4*cm, 7*cm
    c.drawImage(buf, 2*cm, height/2 - image_height/2, width = image_width, height =image_height )

    c.showPage() # Finish the current page and move to the next page
    c.save() # Save the file to disk and close the file



    


if __name__ == "__main__":
    generatePDF("output.pdf") # Ensures when calling generatePDF function, it produces the pdf.